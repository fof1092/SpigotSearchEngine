# SpigotSearchEngine
SpigotSearchEngine is a Browser Extension, it will help you to find any Resources on SpigotMC
